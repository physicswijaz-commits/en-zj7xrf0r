/* ==========================================================================
   English Grammar — MCQ test engine + hub progress
   • Options hide the answer until one is tapped; then the correct option is
     marked, the chosen wrong one is marked, and the reason appears.
   • Answers are saved per page in localStorage ('grammarQuiz') and restored.
   ========================================================================== */
(function () {
  'use strict';
  var KEY = 'grammarQuiz', page = location.pathname.split('/').pop();
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } }
  function save(all) { try { localStorage.setItem(KEY, JSON.stringify(all)); } catch (e) {} }
  var LET = ['A', 'B', 'C', 'D'];

  function reveal(m, chosen, animate) {
    var correct = +m.getAttribute('data-correct');
    m.classList.add('answered');
    m.querySelectorAll('.mcq-opt').forEach(function (b, i) {
      b.disabled = true; b.setAttribute('aria-disabled', 'true');
      b.classList.remove('correct', 'wrong', 'dim');
      var mark = b.querySelector('.mcq-mark');
      if (i === correct) { b.classList.add('correct'); mark.textContent = '✓'; }
      else if (i === chosen) { b.classList.add('wrong'); mark.textContent = '✗'; }
      else { b.classList.add('dim'); mark.textContent = ''; }
    });
    var why = m.querySelector('.mcq-why'), v = why.querySelector('.mcq-verdict');
    why.hidden = false; why.classList.toggle('ok', chosen === correct); why.classList.toggle('bad', chosen !== correct);
    v.textContent = chosen === correct ? 'Correct ✓'
      : 'Wrong ✗ — correct answer: (' + LET[correct] + ') ' + m.querySelectorAll('.mcq-t')[correct].textContent;
  }
  function tally(sec) {
    var all = load(), st = all[page] || {}, done = 0, ok = 0, qs = sec.querySelectorAll('.mcq');
    qs.forEach(function (m) { var a = st[m.getAttribute('data-q')]; if (typeof a === 'number') { done++; if (a === +m.getAttribute('data-correct')) ok++; } });
    sec.querySelector('.ms-done').textContent = done; sec.querySelector('.ms-ok').textContent = ok;
    var res = sec.querySelector('.mcq-result');
    if (done === qs.length && qs.length) {
      var pct = Math.round(ok * 100 / qs.length);
      res.hidden = false;
      res.innerHTML = '<b>' + ok + ' / ' + qs.length + '</b><span>' + (pct === 100 ? 'Perfect score! All answers are correct.' : pct >= 60 ? 'Good work — re-read the reasons for the ones you missed.' : 'Needs more revision — go over the notes and retake the test.') + '</span>';
    } else { res.hidden = true; res.innerHTML = ''; }
  }
  function initQuiz(sec) {
    var all = load(), st = all[page] || {}, total = sec.querySelectorAll('.mcq').length;
    sec.querySelectorAll('.mcq').forEach(function (m) {
      var id = m.getAttribute('data-q');
      if (typeof st[id] === 'number') reveal(m, st[id]);
      m.querySelectorAll('.mcq-opt').forEach(function (b) {
        b.addEventListener('click', function () {
          if (m.classList.contains('answered')) return;
          var a = load(); a[page] = a[page] || {}; a[page][id] = +b.getAttribute('data-i'); a[page]._t = total; save(a);
          reveal(m, +b.getAttribute('data-i'), true); tally(sec);
          var why = m.querySelector('.mcq-why'); setTimeout(function () { why.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 60);
        });
      });
    });
    sec.querySelector('.mcq-reset').addEventListener('click', function () {
      if (!confirm('Retake the test? Your previous answers will be cleared.')) return;
      var a = load(); delete a[page]; save(a);
      sec.querySelectorAll('.mcq').forEach(function (m) {
        m.classList.remove('answered'); m.querySelector('.mcq-why').hidden = true;
        m.querySelectorAll('.mcq-opt').forEach(function (b) { b.disabled = false; b.removeAttribute('aria-disabled'); b.classList.remove('correct', 'wrong', 'dim'); b.querySelector('.mcq-mark').textContent = ''; });
      });
      tally(sec); sec.scrollIntoView({ block: 'start' });
    });
    tally(sec);
  }
  document.querySelectorAll('section#mcq').forEach(initQuiz);

  /* hub: show each topic's test result on its card */
  document.querySelectorAll('.lc[data-g]').forEach(function (lc) {
    var st = load()[lc.getAttribute('data-g')]; if (!st) return;
    var qs = Object.keys(st).filter(function (k) { return k !== '_t'; }), total = st._t || 5;
    if (!qs.length) return;
    var ok = 0; /* correctness is recomputed on the topic page; here we show progress only */
    var meta = lc.querySelector('.card-poet'), s = document.createElement('span');
    s.className = 'lc-pct'; s.textContent = 'Test: ' + qs.length + '/' + total; meta.appendChild(s);
    lc.style.setProperty('--p', Math.round(qs.length * 100 / total) + '%');
  });
})();
