/* ==========================================================================
   — Reading theme switcher (Light / Sepia / Dark)
   The <head> inline snippet on every page already applies the saved class
   to <html> before first paint (no flash). This file just wires up the
   three swatch dots found in the header and keeps the choice in
   localStorage across the whole site.
   ========================================================================== */
(function () {
  const KEY = 'theme';

  function apply(theme) {
    const root = document.documentElement;
    root.classList.remove('dark', 'sepia');
    if (theme === 'dark' || theme === 'sepia') root.classList.add(theme);
    document.querySelectorAll('.theme-dot').forEach((dot) => {
      dot.classList.toggle('active', dot.getAttribute('data-t') === theme);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const root = document.documentElement;
    const stored = localStorage.getItem(KEY);
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const current = stored || (systemPrefersDark ? 'dark' : 'light');

    /* Sync the dots' active state to whatever the head snippet already
       applied (it only reads localStorage — it never guesses system
       preference — so make sure that first-run case is reflected here too). */
    if (!stored && systemPrefersDark) root.classList.add('dark');
    document.querySelectorAll('.theme-dot').forEach((dot) => {
      dot.classList.toggle('active', dot.getAttribute('data-t') === current);
    });

    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    document.querySelectorAll('.theme-dot').forEach((dot) => {
      dot.addEventListener('click', () => {
        const t = dot.getAttribute('data-t');
        localStorage.setItem(KEY, t);
        apply(t);
        if (!reduceMotion) {
          dot.classList.remove('pop');
          void dot.offsetWidth;
          dot.classList.add('pop');
        }
      });
    });
  });
})();
