/* ==========================================================================
   — Tap ripple
   A small expanding-circle ripple from the tap point, on cards, buttons and
   nav items across the site. Purely decorative — never blocks the
   underlying click/tap. No-ops entirely under prefers-reduced-motion.
   ========================================================================== */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const SELECTOR = '.card, .tab-item, .theme-dot, .vocab-promo, .qa-question, ' +
    '.quiz-mark-btn, .exam-reveal-btn, #back-top, .side-bank-link';

  document.addEventListener('pointerdown', (e) => {
    const el = e.target.closest(SELECTOR);
    if (!el || el.disabled) return;

    el.classList.add('ripple-host');

    const rect = el.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 1.4;
    const x = (typeof e.clientX === 'number' ? e.clientX : rect.left + rect.width / 2) - rect.left - size / 2;
    const y = (typeof e.clientY === 'number' ? e.clientY : rect.top + rect.height / 2) - rect.top - size / 2;

    const span = document.createElement('span');
    span.className = 'ripple';
    span.style.width = span.style.height = size + 'px';
    span.style.left = x + 'px';
    span.style.top = y + 'px';
    el.appendChild(span);
    span.addEventListener('animationend', () => span.remove());
  }, { passive: true });
})();
