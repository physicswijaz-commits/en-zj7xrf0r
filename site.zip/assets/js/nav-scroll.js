/* ==========================================================================
   — Header + bottom tab-bar auto-hide on scroll
   While reading (scrolling down), the sticky header and fixed tab-bar both
   slide out of view to give the page more room. Scrolling up, or reaching
   the top/bottom of the page, brings them back immediately.
   ========================================================================== */
(function () {
  const header = document.querySelector('header');
  const tabBar = document.querySelector('.tab-bar');
  if (!header && !tabBar) return;

  let lastY = window.scrollY;
  let ticking = false;

  function onScroll() {
    const y = window.scrollY;
    const goingDown = y > lastY;
    const pastThreshold = y > 80;
    const nearBottom = window.innerHeight + y >= document.documentElement.scrollHeight - 40;
    const shouldHide = goingDown && pastThreshold && !nearBottom;

    if (tabBar) tabBar.classList.toggle('nav-hidden', shouldHide);
    if (header) {
      header.classList.toggle('nav-hidden', shouldHide);
      header.classList.toggle('elevated', y > 4);
    }

    lastY = y;
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(onScroll);
      ticking = true;
    }
  }, { passive: true });
})();

/* back-to-top progress ring: sets --p (0-100) from the scroll position */
(function () {
  var b = document.getElementById('back-top'); if (!b) return;
  function upd() {
    var h = document.documentElement.scrollHeight - window.innerHeight;
    b.style.setProperty('--p', h > 0 ? Math.min(100, Math.max(0, window.scrollY / h * 100)).toFixed(1) : 0);
  }
  window.addEventListener('scroll', upd, { passive: true }); window.addEventListener('resize', upd); upd();
})();
