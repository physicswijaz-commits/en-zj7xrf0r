/* ==========================================================================
   Highlight tool — tap a paragraph or list item and confirm to bookmark it
   as an important point; the confirmation step avoids accidentally marking
   something while just reading. Persisted per chapter.
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  const blocks = document.querySelectorAll('section.topic p, section.topic li');
  if (!blocks.length) return;

  const page = location.pathname.split('/').pop();
  const KEY = 'highlights:' + page;

  function loadHighlights() {
    try { return new Set(JSON.parse(localStorage.getItem(KEY) || '[]')); }
    catch (e) { return new Set(); }
  }
  function saveHighlights(set) { localStorage.setItem(KEY, JSON.stringify([...set])); }
  const highlighted = loadHighlights();

  let confirmBar = null;
  let pendingBlock = null;

  function closeConfirm() {
    if (pendingBlock) pendingBlock.classList.remove('hl-pending');
    pendingBlock = null;
    if (confirmBar) {
      const bar = confirmBar;
      confirmBar = null;
      bar.classList.remove('show');
      setTimeout(() => bar.remove(), 200);
    }
  }

  function openConfirm(block, index) {
    closeConfirm();
    pendingBlock = block;
    block.classList.add('hl-pending');

    confirmBar = document.createElement('div');
    confirmBar.className = 'hl-confirm';
    confirmBar.innerHTML =
      '<span class="hl-confirm-msg"><i data-lucide="bookmark-plus"></i>Bookmark this point?</span>' +
      '<span class="hl-confirm-actions">' +
        '<button class="hl-confirm-yes" aria-label="Yes, bookmark it"><i data-lucide="check"></i></button>' +
        '<button class="hl-confirm-no" aria-label="Cancel"><i data-lucide="x"></i></button>' +
      '</span>';
    document.body.appendChild(confirmBar);
    if (window.lucide) lucide.createIcons();
    requestAnimationFrame(() => requestAnimationFrame(() => confirmBar && confirmBar.classList.add('show')));

    confirmBar.querySelector('.hl-confirm-yes').addEventListener('click', () => {
      highlighted.add(index);
      saveHighlights(highlighted);
      block.classList.add('hl-on');
      closeConfirm();
    });
    confirmBar.querySelector('.hl-confirm-no').addEventListener('click', closeConfirm);
  }

  blocks.forEach((el, i) => {
    el.classList.add('hl-block');
    if (highlighted.has(i)) el.classList.add('hl-on');

    el.addEventListener('click', (e) => {
      if (e.target.closest('a')) return;

      if (el.classList.contains('hl-on')) {
        el.classList.remove('hl-on');
        highlighted.delete(i);
        saveHighlights(highlighted);
        if (pendingBlock === el) closeConfirm();
        return;
      }

      if (pendingBlock === el) { closeConfirm(); return; }

      openConfirm(el, i);
    });
  });

  window.addEventListener('scroll', () => { if (pendingBlock) closeConfirm(); }, { passive: true });
});
