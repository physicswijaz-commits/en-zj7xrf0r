/* ==========================================================================
   Flashcards page logic (flashcards.html)
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof VOCAB_CORE === 'undefined') return;
  const srs = typeof VocabSRS !== 'undefined' ? VocabSRS : null;

  const PROGRESS_KEY = 'flashcardProgress'; // { "word-lowercase": "know" | "learning" }
  const MINE_KEY = 'myVocab';

  function loadMine() {
    try { return JSON.parse(localStorage.getItem(MINE_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function loadProgress() {
    try { return JSON.parse(localStorage.getItem(PROGRESS_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function saveProgress(p) { localStorage.setItem(PROGRESS_KEY, JSON.stringify(p)); }

  function allEntries() {
    const mine = loadMine().map((w) => ({ ...w, source: 'mine' }));
    return VOCAB_CORE.concat(mine);
  }

  const filtersEl = document.getElementById('fc-filters');
  const card = document.getElementById('fc-card');
  const wordEl = document.getElementById('fc-word');
  const tagEl = document.getElementById('fc-tag');
  const meaningEl = document.getElementById('fc-meaning');
  const exampleEl = document.getElementById('fc-example');
  const progressText = document.getElementById('fc-progress-text');
  const stage = document.getElementById('fc-stage');
  const actions = document.querySelector('.fc-actions');
  const emptyEl = document.getElementById('fc-empty');
  const emptyText = document.getElementById('fc-empty-text');

  let filter = 'all';
  let deck = [];
  let pos = 0;
  let progress = loadProgress();

  function buildDeck() {
    const entries = allEntries();
    let pool = entries;
    if (filter === 'mine') pool = entries.filter((e) => e.source === 'mine');
    if (filter === 'learning') pool = entries.filter((e) => progress[e.word.toLowerCase()] === 'learning');
    if (filter === 'due') {
      const srsState = srs ? srs.load() : {};
      pool = srs ? entries.filter((e) => srs.isDue(srsState, e.word)) : [];
    }

    // Weight: words marked "still learning" show up twice as often this session.
    let weighted = [];
    pool.forEach((e) => {
      const status = progress[e.word.toLowerCase()];
      weighted.push(e);
      if (status === 'learning') weighted.push(e);
    });
    // Shuffle (Fisher–Yates)
    for (let i = weighted.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [weighted[i], weighted[j]] = [weighted[j], weighted[i]];
    }
    deck = weighted;
    pos = 0;
  }

  function showCard() {
    card.classList.remove('flipped');
    if (!deck.length) {
      stage.style.display = 'none';
      actions.style.display = 'none';
      document.querySelector('.fc-progress-row').style.display = 'none';
      emptyEl.style.display = 'block';
      emptyText.textContent = filter === 'learning'
        ? "You've cleared your \"Still Learning\" pile — nice work! Switch filters or add more words."
        : filter === 'due'
        ? "You're all caught up — nothing due for review right now. Come back later!"
        : 'No words in this filter yet.';
      return;
    }
    stage.style.display = '';
    actions.style.display = '';
    document.querySelector('.fc-progress-row').style.display = '';
    emptyEl.style.display = 'none';

    const entry = deck[pos];
    wordEl.textContent = entry.word;
    tagEl.textContent = entry.source === 'mine' ? '★ My Word' : 'Ch ' + entry.chapter;
    meaningEl.textContent = entry.meaning;
    exampleEl.textContent = entry.example ? '"' + entry.example + '"' : '';
    exampleEl.style.display = entry.example ? '' : 'none';
    progressText.textContent = (pos + 1) + ' / ' + deck.length;
  }

  function advance() {
    pos++;
    if (pos >= deck.length) buildDeck();
    showCard();
  }

  function mark(status) {
    if (!deck.length) return;
    const word = deck[pos].word;
    progress[word.toLowerCase()] = status;
    saveProgress(progress);
    if (srs) srs.grade(word, status === 'know');
    advance();
  }

  card.addEventListener('click', () => card.classList.toggle('flipped'));
  document.getElementById('fc-mark-learning').addEventListener('click', () => mark('learning'));
  document.getElementById('fc-mark-know').addEventListener('click', () => mark('know'));
  document.getElementById('fc-shuffle').addEventListener('click', () => { buildDeck(); showCard(); });

  filtersEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.vb-filter-chip');
    if (!btn) return;
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    filter = btn.dataset.filter;
    buildDeck();
    showCard();
  });

  buildDeck();
  showCard();
});
